<template>
  <div class="repository-box">
    <div class="repository" >
      <div >fate-repository</div>
    </div>
  </div>
</template>

<script>

export default {
    name: 'Loginhome',
    components: {

    },
    data() {
        return {
        }
    },
    methods: {
    // 切换

    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .repository-box{
        font-size: 25px;
        color: pink;
    }
</style>
