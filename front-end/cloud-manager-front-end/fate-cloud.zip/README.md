# fate cloud manager
cloud-manager

## Build Setup

# Install dependencies
npm install

# Serve with hot reload at localhost:8080
npm run serve

# Build for production with minification
npm run build

# Build for production and view the bundle analyzer report
npm run build --report
```


